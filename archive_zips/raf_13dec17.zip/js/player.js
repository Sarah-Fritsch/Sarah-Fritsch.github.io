(function($) {
    "use strict";

    if ($('.audio-player').length) {
        var context;
        var bufferLoader;
        var myAudioBuffer = null;
        var source = null;
        var isPlaying = false;
        var songVault = ['Now.wav'];
        var url = 'http://www.jplayer.org/audio/mp3/TSP-01-Cro_magnon_man.mp3'
            //demo = 'audio/' + songVault[0];

        // Load song
        var init = initContext();
        loadSound(url);

        // Event handlers
        $('.jp-play').click(function() {
            if (!isPlaying) {
                playSound(myAudioBuffer);
                isPlaying = true;
                togglePlayButton();
            } else {
                stopSound(myAudioBuffer);
                isPlaying = false;
                togglePlayButton();
            }
        });
        // Functions
        function initContext () {
            try {
                context = new AudioContext();
                console.log('ready');
            }
            catch(e) {
                alert('Sorry, your browser does not support this audio player.');
            }
        }
        function loadSound (url) {
            var request = new XMLHttpRequest();
            request.open('GET', url, true);
            request.responseType = 'arraybuffer';
            request.onload = function () {
                context.decodeAudioData(request.response, function(buffer) {
                    myAudioBuffer = buffer;
                });
            }
            request.send();
        }
        function playSound (anyBuffer) {
            var gainNode = context.createGain();
            source = context.createBufferSource();
            source.buffer = anyBuffer;

            source.connect(gainNode);
            gainNode.connect(context.destination);
            gainNode.gain.value = 0.5;

            source.start();

            console.log(document.getElementById('volume-value'));
            document.getElementById('volume-value').addEventListener('change', function() {
                gainNode.gain.value = this.value;
            });
        }
        function stopSound () {
            if (source) {
                source.stop();
            }
        }
        function togglePlayButton () {
            if (isPlaying) {
                $('.fa-play').hide(); 
                $('.fa-pause').show(); 
            } else {
                $('.fa-pause').hide(); 
                $('.fa-play').show(); 
            }
        }
    }
})(jQuery);
